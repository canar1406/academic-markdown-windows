# Bắt đầu nhanh — Template LaTeX

> Chỉ cần nhớ **3 chỗ**: `config.tex` (chọn in gì) · `input/` (danh sách in) · `data/` (nội dung gõ).

Biên dịch luôn từ **`main.tex`**.

---

## 0. Chọn chế độ — sửa `config.tex`

**In đề thi:**
```latex
\def\DocMode{exam}
\def\ExamBundle{mau}      % tên file trong input/Dethi/12/
\def\ExamGrade{12}
```

**In sách:**
```latex
\def\DocMode{book}
\def\BookManifest{input/theory/mau/chuong-mau}
```

---

## 1. Thêm đề thi mới (3 bước)

### Bước 1 — Tạo file nội dung (gõ câu hỏi)

Copy mẫu, đổi tên, gõ đề:

| Loại đề | Copy từ | Lưu thành |
|---------|---------|-----------|
| Trắc nghiệm | `data/templates/de-tn-mau.tex` | `data/Dethi/<tên-nhóm>/TenDe.tex` |
| Tự luận | `data/templates/de-tl-mau.tex` | `data/Dethi/<tên-nhóm>/TenDe.tex` |

Ví dụ: `data/Dethi/Demo/De01.tex` (đã có sẵn trong template).

### Bước 2 — Khai báo vào danh sách in

Mở (hoặc tạo) file manifest, ví dụ `input/Dethi/12/mau.tex`:

```latex
\chapter{BỘ ĐỀ CỦA TÔI}
\input{data/Dethi/Demo/De01}
% \input{data/Dethi/Demo/De02}   ← thêm dòng khi có đề mới
```

**Manifest** = file chỉ liệt kê đề nào được in, **không** gõ câu hỏi ở đây.

### Bước 3 — Chọn bộ đề trong `config.tex`

```latex
\def\DocMode{exam}
\def\ExamBundle{mau}    % = tên file manifest (không .tex)
\def\ExamGrade{12}
```

→ Biên dịch `main.tex`.

### Tạo bộ đề mới (khác `mau`)

1. Tạo `input/Dethi/12/BoDe01.tex` (manifest mới).
2. Trong đó `\input{data/Dethi/...}` các đề.
3. `config.tex`: `\def\ExamBundle{BoDe01}`.

---

## 2. Thêm sách / lý thuyết (3 bước)

### Bước 1 — Gõ nội dung

| Việc | File (ví dụ) |
|------|----------------|
| Lý thuyết | `data/theory/mau/B1/lt-mau.tex` |
| Bài tập | `data/theory/mau/B1/bt-dang1-mau.tex` |

Chỉ gõ nội dung (`definition`, `theorem`, `ex`…). **Không** đặt `\chapter` / `\section` trong file này.

### Bước 2 — Ghép bài (manifest bài)

Sửa `input/theory/mau/bai-mau.tex`:

```latex
\section{TÊN BÀI}
\subsection{LÝ THUYẾT}
\input{data/theory/mau/B1/lt-mau}
\subsection{CÁC DẠNG BÀI TẬP}
\input{data/theory/mau/B1/bt-dang1-mau}
```

### Bước 3 — Ghép chương (manifest chương)

Sửa `input/theory/mau/chuong-mau.tex`:

```latex
\chapter{TÊN CHƯƠNG}
\input{bai-mau}
% \input{bai-mau-02}   ← thêm bài mới
```

`config.tex`:
```latex
\def\DocMode{book}
\def\BookManifest{input/theory/mau/chuong-mau}
```

→ Biên dịch `main.tex`.

### Thêm chương mới

1. Copy thư mục `input/theory/mau/` → `input/theory/12_C1/`.
2. Copy `data/theory/mau/` → `data/theory/12_C1/`.
3. Sửa đường dẫn `\input{data/theory/12_C1/...}` trong manifest bài.
4. `config.tex`: `\def\BookManifest{input/theory/12_C1/chuong-mau}`.

---

## 3. Sơ đồ 1 trang

```
config.tex          ← BẠN CHỌN: exam hay book, bundle nào
    ↓
main.tex            ← BIÊN DỊCH FILE NÀY
    ↓
┌─ exam ─────────────────────────────────────────┐
│  input/Dethi/12/mau.tex     (danh sách đề)     │
│       ↓                                        │
│  data/Dethi/Demo/De01.tex   (nội dung đề)      │
└────────────────────────────────────────────────┘

┌─ book ─────────────────────────────────────────┐
│  input/theory/mau/chuong-mau.tex  (chương)   │
│       ↓                                        │
│  input/theory/mau/bai-mau.tex     (bài)        │
│       ↓                                        │
│  data/theory/mau/B1/lt-mau.tex    (lý thuyết) │
│  data/theory/mau/B1/bt-dang1.tex  (bài tập)    │
└────────────────────────────────────────────────┘
```

---

## 4. Câu hỏi thường gặp

| Vấn đề | Kiểm tra |
|--------|----------|
| Đổi bộ đề không ăn | `\ExamBundle` khớp tên file trong `input/Dethi/<ExamGrade>/` |
| Sách không đổi | `\DocMode{book}` và `\BookManifest` trỏ đúng manifest chương |
| Lỗi không tìm file | Đường `\input{...}` trong manifest có đúng đường dẫn không |
| Muốn xem lời giải | `\ExTestOption{loigiai}` trong `config.tex` |

---

## 5. File mẫu có sẵn (demo)

| File | Dùng để |
|------|---------|
| `input/Dethi/12/mau.tex` | Manifest đề demo |
| `data/Dethi/Demo/De01.tex` | Nội dung đề demo |
| `data/templates/de-tn-mau.tex` | Khung copy đề TN |
| `data/templates/de-tl-mau.tex` | Khung copy đề TL |
| `input/theory/mau/chuong-mau.tex` | Manifest chương |
| `input/theory/mau/bai-mau.tex` | Manifest bài |
| `data/theory/mau/B1/lt-mau.tex` | Lý thuyết mẫu |
| `data/theory/mau/B1/bt-dang1-mau.tex` | Bài tập mẫu |

Chi tiết đầy đủ (lệnh, lọc phần đề, dongke…): **`HUONG-DAN.md`**.
