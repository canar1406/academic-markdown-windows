# Template LaTeX — Sách & Đề thi

Bộ mẫu cho **đề thi** (TN / TL) và **sách lý thuyết**.

## Bắt đầu

1. Đọc **`BAT-DAU-NHANH.md`** (hướng dẫn ngắn, từng bước).
2. Sửa **`config.tex`**.
3. Biên dịch **`main.tex`**.

```bash
pdflatex main.tex
```

## Ba chỗ cần nhớ

| Chỗ | Làm gì |
|-----|--------|
| **`config.tex`** | Chọn in đề hay sách, chọn bộ nào |
| **`input/`** | Danh sách file sẽ in (manifest) |
| **`data/`** | Nội dung bạn gõ (câu hỏi, lý thuyết) |

## Demo có sẵn

**Đề thi** — `config.tex`:
```latex
\def\DocMode{exam}
\def\ExamBundle{mau}
\def\ExamGrade{12}
```

**Sách** — `config.tex`:
```latex
\def\DocMode{book}
\def\BookManifest{input/theory/mau/chuong-mau}
```

Chi tiết đầy đủ: **`HUONG-DAN.md`**
