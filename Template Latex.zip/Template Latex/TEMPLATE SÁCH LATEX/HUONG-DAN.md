# Hướng dẫn Template LaTeX — Sách & Đề thi

> **Mới dùng?** Đọc trước **`BAT-DAU-NHANH.md`** (ngắn, từng bước). File này là bản chi tiết đầy đủ.

Template dùng chung cho **sách lý thuyết** (book) và **đề thi** (trắc nghiệm / tự luận), engine **pdfLaTeX + vietnam**, gói `ex_test.sty`.

---

## Mục lục

1. [Chạy template](#1-chạy-template)
2. [Bản đồ vị trí file](#2-bản-đồ-vị-trí-file)
3. [Tạo đề thi](#3-tạo-đề-thi)
4. [Tạo sách lý thuyết](#4-tạo-sách-lý-thuyết)
5. [Trích một phần đề](#5-trích-một-phần-đề)
6. [Phụ lục: Lệnh & lưu ý](#6-phụ-lục-lệnh--lưu-ý)

---

## 1. Chạy template

### Bước chung (mọi chế độ)

1. Mở thư mục gốc project (chứa `main.tex`).
2. Sửa **`config.tex`** — chọn `book` hoặc `exam` (xem bảng bên dưới).
3. Biên dịch — xem [Biên dịch từ file con](#biên-dịch-từ-file-con-teXstudio--vscode) bên dưới.

```bash
pdflatex main.tex
```

Chạy thêm lần 2 nếu cần cập nhật tham chiếu chéo / đáp án.

> **Quan trọng:** `main.tex` là điểm vào duy nhất. Không gõ nội dung đề hay sách trực tiếp trong `main.tex`.

### Biên dịch từ file con (TeXstudio / VS Code)

Các file nội dung (`data/…`, `input/…`, `config.tex`) đã có dòng magic ở **dòng đầu tiên**:

```latex
% !TeX root = ../../../main.tex
```

**TeXstudio**

1. Mở `main.tex` (một lần — để IDE nhận project).
2. Mở file đang soạn (vd. `lt-mau.tex`).
3. Nhấn **Build & View** (F5) — TeXstudio tự biên dịch `main.tex` và ra `main.pdf`.

Nếu file mới tự tạo chưa có dòng `% !TeX root`, thêm dòng đó trỏ về `main.tex` (đếm số cấp thư mục `../`).

**VS Code + LaTeX Workshop**

Project đã có `.vscode/settings.json` cố định root là `main.tex`. Mở file con rồi build — vẫn ra `main.pdf`.

**File mới — quy tắc đường dẫn `% !TeX root`**

| Vị trí file | Dòng magic |
|-------------|------------|
| `config.tex` | `% !TeX root = main.tex` |
| `data/templates/*.tex` | `% !TeX root = ../../main.tex` |
| `data/theory/mau/B1/*.tex` | `% !TeX root = ../../../../main.tex` |
| `input/theory/mau/*.tex` | `% !TeX root = ../../../main.tex` |
| `input/Dethi/12/*.tex` | `% !TeX root = ../../../main.tex` |

### Cấu hình `config.tex`

| Biến | Giá trị | Khi nào dùng |
|------|---------|--------------|
| `\DocMode` | `exam` | In đề thi |
| `\DocMode` | `book` | In sách / tài liệu lý thuyết |
| `\ExamBundle` | tên file (không `.tex`) | Chỉ **exam** — chọn manifest trong `input/Dethi/12/` |
| `\ExTestOption` | `dethi` / `loigiai` / `dongke` / `book` | Cách hiển thị câu hỏi & lời giải |
| `\NoteLayout` | `0` / `1` | `1` = cột GHI CHÚ + dongke |
| `\ExamPartFilter` | `all` / `I` / `II` / `III` / `IV` | Chỉ **exam** — in một phần |
| `\AuthorName`, `\EvenHeaderTitle` | tuỳ chỉnh | Header/footer |

**Ví dụ — in demo đề tự luận:**

```latex
\def\DocMode{exam}
\def\ExamBundle{mau}
\def\ExTestOption{dethi}
\def\NoteLayout{0}
```

**Ví dụ — in demo sách mẫu:**

```latex
\def\DocMode{book}
\def\ExTestOption{loigiai}
\def\NoteLayout{0}
```

### Luồng biên dịch

```
config.tex
  → preamble/ (packages, layout, ex_test…)
\begin{document}
  DocMode = exam  → modes/exam.tex
                  → input/Dethi/12/<ExamBundle>.tex   ← manifest
                  → data/Dethi/.../ten-de.tex         ← nội dung đề

  DocMode = book  → modes/book.tex
                  → data/theory/chuong-mau.tex        ← điểm vào sách
                  → input/theory/mau/chuong-mau.tex   ← manifest chương
                  → data/theory/mau/B1/lt-mau.tex …   ← nội dung
\end{document}
```

---

## 2. Bản đồ vị trí file

### Cây thư mục chính

```
TEMPLATE SÁCH LATEX/
├── main.tex                 ← BIÊN DỊCH FILE NÀY
├── config.tex               ← CHỌN CHẾ ĐỘ & TUỲ CHỈNH
├── ex_test.sty
│
├── modes/
│   ├── exam.tex             ← nạp manifest đề (đừng sửa trừ khi biết rõ)
│   └── book.tex             ← nạp sách (không bìa, không mục lục)
│
├── input/
│   ├── Dethi/12/            ← MANIFEST ĐỀ THI (liệt kê \input đề)
│   │   └── mau.tex
│   └── theory/mau/          ← MANIFEST SÁCH (ghép chương / bài)
│       ├── chuong-mau.tex
│       └── bai-mau.tex
│
├── data/
│   ├── templates/           ← MẪU COPY-PASTE (de-tn-mau, de-tl-mau)
│   ├── Dethi/               ← NỘI DUNG ĐỀ THI (tạo thư mục loại của bạn)
│   └── theory/
│       ├── chuong-mau.tex   ← điểm vào book mode
│       └── mau/B1/          ← nội dung LT + BT mẫu
│
├── preamble/                ← cấu hình layout (không sửa khi mới dùng)
├── declare/                 ← lệnh \caulc, \cauds…
├── ans/                     ← đáp án tự sinh khi biên dịch (có thể xoá)
├── figure/                  ← đặt hình ảnh đề / sách tại đây
└── preamble/                ← cấu hình layout (không sửa khi mới dùng)
```

### Bạn cần tạo / sửa file ở đâu?

| Việc cần làm | Tạo hoặc sửa | Khai báo (nạp) | `config.tex` |
|--------------|--------------|----------------|--------------|
| Thêm đề TN mới | Copy `data/templates/de-tn-mau.tex` → `data/Dethi/<loại>/TEN.tex` | Thêm `\input{data/Dethi/...}` vào `input/Dethi/12/<Bundle>.tex` | `\DocMode{exam}`, `\ExamBundle{<Bundle>}` |
| Thêm đề TL mới | Copy `data/templates/de-tl-mau.tex` → `data/Dethi/<loại>/TEN.tex` | Như trên | Như trên |
| Tạo bộ đề mới | Tạo `input/Dethi/12/TEN_BO.tex` | — | `\ExamBundle{TEN_BO}` |
| Thêm chương sách | Copy `input/theory/mau/` → `input/theory/<lop>/` | Sửa `data/theory/chuong-mau.tex` | `\DocMode{book}` |
| Gõ lý thuyết | `data/theory/.../lt-….tex` | Manifest bài `\input{...}` | `\DocMode{book}` |
| Gõ bài tập sách | `data/theory/.../bt-dang….tex` | Manifest bài `\input{...}` | `\DocMode{book}` |

### File mẫu có sẵn (demo)

| File | Vai trò |
|------|---------|
| `data/templates/de-tn-mau.tex` | Khung đề trắc nghiệm 12+4+6 |
| `data/templates/de-tl-mau.tex` | Khung đề tự luận |
| `input/Dethi/12/mau.tex` | Manifest demo (đang nạp `de-tl-mau`) |
| `input/theory/mau/chuong-mau.tex` | Manifest chương mẫu |
| `input/theory/mau/bai-mau.tex` | Manifest bài mẫu |
| `data/theory/mau/B1/lt-mau.tex` | Lý thuyết placeholder |
| `data/theory/mau/B1/bt-dang1-mau.tex` | Bài tập placeholder |

---

## 3. Tạo đề thi

### A. Đề trắc nghiệm (TNTHPT: 3 phần)

**Bước 1 — Tạo file đề**

```text
Copy:  data/templates/de-tn-mau.tex
  →    data/Dethi/<loại>/TEN_DE.tex
```

Ví dụ: `data/Dethi/TNTHPT/De01.tex`

**Bước 2 — Sửa nội dung**

- Đổi `\section{TÊN ĐỀ TRẮC NGHIỆM}`.
- Gõ câu trong `\begin{ex}...\end{ex}`.
- Ranh giới phần: `\caulc` → `\cauds` → `\caukq`.
- Trước mỗi phần mới (II, III): `\Closesolutionfile{ans}` rồi `\Opensolutionfile{ans}[...]`.
- Comment `%%%Phan-I-Cau01`… để tìm nhanh.

**Bước 3 — Khai báo manifest**

Mở (hoặc tạo) `input/Dethi/12/<Bundle>.tex`:

```latex
\chapter{TÊN BỘ ĐỀ}
\input{data/Dethi/TNTHPT/De01}
\input{data/Dethi/TNTHPT/De02}
```

**Bước 4 — Cấu hình & chạy**

```latex
% config.tex
\def\DocMode{exam}
\def\ExamBundle{<Bundle>}    % tên file manifest, không .tex
\def\ExTestOption{dethi}     % dethi | loigiai | dongke
```

```bash
pdflatex main.tex
```

**Demo nhanh:** giữ `\def\ExamBundle{mau}` — manifest `input/Dethi/12/mau.tex` đang nạp trực tiếp `data/templates/de-tl-mau.tex` (bỏ comment dòng `de-tn-mau` để xem đề TN).

---

### B. Đề tự luận

**Bước 1 — Tạo file đề**

```text
Copy:  data/templates/de-tl-mau.tex
  →    data/Dethi/<loại>/TEN_DE.tex
```

**Bước 2 — Sửa nội dung**

```latex
\section{TÊN ĐỀ TỰ LUẬN}
\cautlonly                    % mở phần IV, không \newpage câu đầu
\begin{ex}
  Đề bài…
  \loigiai{Hướng dẫn chấm}
\end{ex}
\Closesolutionfile{ans}
\Closesolutionfile{ansbook}
```

Không dùng `\choice`. Không in block đáp án cuối file (template mẫu đã bỏ).

**Bước 3 — Manifest & config** — giống mục A.

---

### C. Copy cả folder làm dự án mới

1. Copy nguyên thư mục template.
2. Xoá `ans/` (tự sinh lại khi biên dịch).
3. Tạo `data/Dethi/<mục đích>/` và manifest trong `input/Dethi/12/`.
4. Chỉ sửa `config.tex` + file trong `data/` và `input/`.

---

## 4. Tạo sách lý thuyết

Book mode **không** in bìa và mục lục (`modes/book.tex`).

### Cấu trúc (manifest ↔ nội dung)

```
input/theory/mau/              data/theory/mau/B1/
├── chuong-mau.tex             ├── lt-mau.tex        ← gõ lý thuyết
│   \chapter{TÊN CHƯƠNG}       └── bt-dang1-mau.tex ← gõ bài tập
└── bai-mau.tex
    \section{TÊN BÀI}
    \subsection{LÝ THUYẾT}  → \input lt-mau
    \subsection{CÁC DẠNG…}   → \input bt-dang1-mau
```

### Bước 1 — Bật book mode

```latex
% config.tex
\def\DocMode{book}
\def\ExTestOption{loigiai}   % loigiai = hiện LG; dethi = chỉ đề BT
```

### Bước 2 — Tạo chương mới (copy mẫu)

```text
Copy folder:
  input/theory/mau/  →  input/theory/12/12_C1/
  data/theory/mau/   →  data/theory/12/12_C1/
```

Đổi tên file cho rõ (vd. `12_C1.tex`, `12_C1_B1.tex`, `12_C1_B1_LT.tex`…).

### Bước 3 — Manifest chương

`input/theory/12/12_C1/12_C1.tex`:

```latex
\setcounter{chapter}{0}
\setcounter{section}{0}
\setcounter{dang}{0}
\chapter{TÊN CHƯƠNG}
\input{input/theory/12/12_C1/12_C1_B1}
```

### Bước 4 — Manifest bài

`input/theory/12/12_C1/12_C1_B1.tex`:

```latex
\setcounter{section}{0}
\section{TÊN BÀI}

\subsection{LÝ THUYẾT}
\input{data/theory/12/12_C1/B1/12_C1_B1_LT}
\newpage

\subsection{CÁC DẠNG BÀI TẬP}
\input{data/theory/12/12_C1/B1/12_C1_B1_BT_Dang1}
```

### Bước 5 — Gõ nội dung

**Lý thuyết** (`*_LT.tex` hoặc `lt-….tex`) — không đặt `\chapter`/`\section`:

```latex
\subsubsection{Tiêu đề tiểu mục}
\begin{definition}[…] … \end{definition}
\begin{theorem} … \end{theorem}
\begin{notice} … \end{notice}
\begin{example} … \loigiai{…} \end{example}
```

**Bài tập** (`*_BT_Dang1.tex` hoặc `bt-dang1-….tex`):

```latex
\setcounter{subsubsection}{0}
\setcounter{example}{0}
\setcounter{ex}{0}

\begin{dang}[Tên dạng] … \end{dang}
\begin{example}[…] … \loigiai{…} \end{example}

\subsubsection{Bài tập trắc nghiệm…}
\begin{ex} … \choice … \loigiai{…} \end{ex}
```

### Bước 6 — Nạp vào sách & chạy

Sửa `data/theory/chuong-mau.tex`:

```latex
\input{input/theory/mau/chuong-mau}
% thêm chương:
% \input{input/theory/12/12_C1/12_C1}
```

```bash
pdflatex main.tex
```

### Quy ước đặt tên file

| Hậu tố | Ý nghĩa |
|--------|---------|
| `_LT` / `lt-…` | Lý thuyết |
| `_BT_DangN` / `bt-dangN-…` | Bài tập dạng N |
| `_BTSGK` | Bài SGK |
| `_BTRL` | Bài rèn luyện |
| `_Deontap_DeNN` | Đề ôn tập |

| File manifest | Vai trò |
|---------------|---------|
| `chuong-mau.tex` (trong `input/theory/…`) | Ghép các **bài** trong chương |
| `bai-mau.tex` | Ghép **LT + BT** của một bài |
| `data/theory/chuong-mau.tex` | Điểm vào duy nhất từ `modes/book.tex` |

---

## 5. Trích một phần đề

In **chỉ một phần** từ nhiều đề trong cùng bộ:

```latex
% config.tex
\def\ExamBundle{TNTHPT}
\def\ExamPartFilter{II}    % all | I | II | III | IV
```

```bash
pdflatex main.tex
```

| `\ExamPartFilter` | Kết quả |
|-------------------|---------|
| `all` | In đủ phần |
| `I` | Trắc nghiệm 4 phương án |
| `II` | Đúng sai |
| `III` | Trả lời ngắn |
| `IV` | Tự luận |

Ranh giới phần trong file đề: `\caulc`, `\cauds`, `\caukq`, `\cautl` / `\cautlonly`. Logic lọc: `preamble/16-exam-part-filter.tex`.

---

## 6. Phụ lục: Lệnh & lưu ý

### 6.1. Lệnh phần đề

| Lệnh | Phần |
|------|------|
| `\caulc` | I — Trắc nghiệm 4 phương án |
| `\cauds` | II — Đúng sai |
| `\caukq` | III — Trả lời ngắn |
| `\cautl` | IV — Tự luận (có tiêu đề subsection) |
| `\cautlonly` | IV — Tự luận (không tiêu đề, không newpage câu đầu) |

### 6.2. Câu hỏi trắc nghiệm

| `\ExTestOption` | Hiển thị |
|-----------------|----------|
| `dethi` | Đề đầy đủ, ẩn lời giải |
| `loigiai` | Đề + lời giải (hộp question) |
| `dongke` | Dòng chấm + đáp án cuối LG |
| `book` | Ghi LG ra `ansbook` |

**Phần I:** `\choice` + `\True` trên đáp án đúng.

**Phần II:** `\choiceTF` + `\True`.

**Phần III:** `\shortans[oly]{đáp số}`.

**Hình cạnh chữ:** `\immini[0.4]{text}{\begin{tikzpicture}...\end{tikzpicture}}`.

### 6.3. Hộp lý thuyết (book)

| Môi trường | Tiêu đề |
|------------|---------|
| `definition` | Định nghĩa |
| `theorem` | Định lý |
| `proposition` | Mệnh đề |
| `example` | Ví dụ |
| `dang` | Dạng toán |
| `summary` | Tổng kết |
| `notice` | Chú ý |
| `claim` | Nhận định |
| `proof` | Chứng minh (kết thúc bằng $\square$) |

```latex
\begin{theorem}[…]
  Mệnh đề cần chứng minh.
  \begin{proof}
    Các bước chứng minh…
  \end{proof}
\end{theorem}

\begin{proof}[Tùy chọn ghi chú]
  Chứng minh độc lập.
\end{proof}
```

`cminh` vẫn dùng được — tương đương `proof`.

### 6.4. Lỗi thường gặp

| Vấn đề | Cách xử lý |
|--------|------------|
| `ans/...-Phan-II.tex not found` | `\Closesolutionfile{ans}` trước `\cauds`/`\caukq` |
| Đổi bộ đề không ăn | `\ExamBundle` phải khớp tên file trong `input/Dethi/12/` |
| Sách không đổi nội dung | Kiểm tra `\DocMode{book}` và `data/theory/chuong-mau.tex` |
| `\currfilebase` | Tên file đề (không `.tex`) — dùng trong `\Opensolutionfile` |
| Không thấy đáp án TN | Cần `\shortans{...}` + `loigiai` hoặc `dongke` |

### 6.5. Bảng tra nhanh

```
main.tex                    → luôn biên dịch file này
config.tex                  → DocMode, ExamBundle, ExTestOption…
input/Dethi/12/<Bundle>.tex → manifest đề
data/Dethi/...              → nội dung đề
data/templates/             → copy mẫu đề
input/theory/...            → manifest sách
data/theory/...             → nội dung sách
\caulc / \cauds / \caukq    → mở phần I–III
\cautlonly                  → mở phần IV (đề TL)
pdflatex main.tex           → chạy
```
